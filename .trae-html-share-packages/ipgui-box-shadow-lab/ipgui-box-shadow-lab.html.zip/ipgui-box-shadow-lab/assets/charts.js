/* Cost comparison chart for IPGUI shadow pipeline */
(function () {
  var el = document.getElementById('chart-cost');
  if (!el || typeof echarts === 'undefined') return;

  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim() || '#35e0ff';
  var accent2 = style.getPropertyValue('--accent2').trim() || '#9be15d';
  var ink = style.getPropertyValue('--ink').trim() || '#e8eef7';
  var muted = style.getPropertyValue('--muted').trim() || '#8b97a8';
  var rule = style.getPropertyValue('--rule').trim() || '#243041';
  var bg2 = style.getPropertyValue('--bg2').trim() || '#121820';

  var chart = echarts.init(el, null, { renderer: 'svg' });
  chart.setOption({
    animation: false,
    backgroundColor: 'transparent',
    tooltip: { appendToBody: true, trigger: 'axis' },
    legend: {
      data: ['全尺寸 2D 高斯', '可分离 3-Pass Box', '缓存命中后'],
      textStyle: { color: muted },
      top: 0
    },
    grid: { left: 48, right: 18, top: 48, bottom: 36 },
    xAxis: {
      type: 'category',
      data: ['64²', '128²', '256²', '512²'],
      axisLabel: { color: muted },
      axisLine: { lineStyle: { color: rule } }
    },
    yAxis: {
      type: 'log',
      name: '相对算力 (log)',
      nameTextStyle: { color: muted },
      axisLabel: { color: muted },
      splitLine: { lineStyle: { color: rule, opacity: 0.45 } }
    },
    series: [
      {
        name: '全尺寸 2D 高斯',
        type: 'bar',
        data: [18, 72, 290, 1180],
        itemStyle: { color: accent2 + '99' }
      },
      {
        name: '可分离 3-Pass Box',
        type: 'bar',
        data: [3.2, 7.5, 18, 46],
        itemStyle: { color: accent }
      },
      {
        name: '缓存命中后',
        type: 'bar',
        data: [0.2, 0.35, 0.7, 1.4],
        itemStyle: { color: ink }
      }
    ]
  });
  window.addEventListener('resize', function () { chart.resize(); });
})();
