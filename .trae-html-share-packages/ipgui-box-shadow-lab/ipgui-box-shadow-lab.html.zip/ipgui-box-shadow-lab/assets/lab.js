/* IPGUI Box Shadow Lab — interactive demos */
(function () {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function lerp(a, b, t) { return a + (b - a) * t; }

  /* ========== Core algorithm port (A8 mask) ========== */
  function shadowKernel(blur) {
    if (blur <= 0) return 1;
    let kn = Math.floor(blur / 2) + 1;
    if (kn < 3) kn = 3;
    if ((kn & 1) === 0) kn++;
    return kn;
  }

  function shadowBlurPad(kn) {
    return kn <= 1 ? 0 : 3 * Math.floor(kn / 2);
  }

  function roundedRectCoverage(px, py, cw, ch, radii) {
    const [rlt, rrt, rlb, rbr] = radii;
    if (px < 0 || py < 0 || px >= cw || py >= ch) return 0;

    let r = 0, cx = 0, cy = 0, inCorner = false;
    if (px < rlt && py < rlt) { r = rlt; cx = rlt; cy = rlt; inCorner = true; }
    else if (px >= cw - rrt && py < rrt) { r = rrt; cx = cw - rrt; cy = rrt; inCorner = true; }
    else if (px < rlb && py >= ch - rlb) { r = rlb; cx = rlb; cy = ch - rlb; inCorner = true; }
    else if (px >= cw - rbr && py >= ch - rbr) { r = rbr; cx = cw - rbr; cy = ch - rbr; inCorner = true; }

    if (!inCorner || r <= 0) return 255;

    const dx = px + 0.5 - cx;
    const dy = py + 0.5 - cy;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const aa = 0.75;
    if (dist <= r - aa) return 255;
    if (dist >= r + aa) return 0;
    const t = (r + aa - dist) / (2 * aa);
    return Math.round(255 * clamp(t, 0, 1));
  }

  function fillShadowMask(mw, mh, pad, cw, ch, radii) {
    const mask = new Uint8Array(mw * mh);
    for (let y = 0; y < ch; y++) {
      for (let x = 0; x < cw; x++) {
        mask[(pad + y) * mw + (pad + x)] = roundedRectCoverage(x, y, cw, ch, radii);
      }
    }
    return mask;
  }

  function blurHorCentered(src, w, h, kn) {
    if (kn <= 1) return src.slice();
    if ((kn & 1) === 0) kn -= 1;
    const r = (kn - 1) >> 1;
    const out = new Uint8Array(w * h);
    for (let y = 0; y < h; y++) {
      let sum = 0;
      for (let k = -r; k <= r; k++) {
        const x = k;
        if (x >= 0 && x < w) sum += src[y * w + x];
      }
      out[y * w] = Math.round(sum / kn);
      for (let x = 1; x < w; x++) {
        const leave = x - 1 - r;
        const enter = x + r;
        if (leave >= 0 && leave < w) sum -= src[y * w + leave];
        if (enter >= 0 && enter < w) sum += src[y * w + enter];
        out[y * w + x] = Math.round(sum / kn);
      }
    }
    return out;
  }

  function blurVerCentered(src, w, h, kn) {
    if (kn <= 1) return src.slice();
    if ((kn & 1) === 0) kn -= 1;
    const r = (kn - 1) >> 1;
    const out = new Uint8Array(w * h);
    for (let x = 0; x < w; x++) {
      let sum = 0;
      for (let k = -r; k <= r; k++) {
        const y = k;
        if (y >= 0 && y < h) sum += src[y * w + x];
      }
      out[x] = Math.round(sum / kn);
      for (let y = 1; y < h; y++) {
        const leave = y - 1 - r;
        const enter = y + r;
        if (leave >= 0 && leave < h) sum -= src[leave * w + x];
        if (enter >= 0 && enter < h) sum += src[enter * w + x];
        out[y * w + x] = Math.round(sum / kn);
      }
    }
    return out;
  }

  function blurPasses(mask, w, h, kn, passes) {
    let cur = mask;
    const p = Math.max(1, passes | 0);
    for (let i = 0; i < p; i++) {
      cur = blurHorCentered(cur, w, h, kn);
      cur = blurVerCentered(cur, w, h, kn);
    }
    return cur;
  }

  function buildShadow(params) {
    const blur = clamp(params.blur | 0, 0, 64);
    const spread = clamp(params.spread | 0, 0, 40);
    const radius = clamp(params.radius | 0, 0, 80);
    const cw = Math.max(4, (params.w | 0) + spread * 2);
    const ch = Math.max(4, (params.h | 0) + spread * 2);
    const r = Math.min(radius + (radius > 0 ? spread : 0), cw >> 1, ch >> 1);
    const radii = [r, r, r, r];
    const kn = shadowKernel(blur);
    const pad = shadowBlurPad(kn);
    const mw = cw + pad * 2;
    const mh = ch + pad * 2;
    const hard = fillShadowMask(mw, mh, pad, cw, ch, radii);
    const soft = blurPasses(hard, mw, mh, kn, params.passes == null ? 3 : params.passes);
    return { hard, soft, mw, mh, pad, cw, ch, kn, radii };
  }

  function drawChecker(ctx, w, h, size = 12) {
    for (let y = 0; y < h; y += size) {
      for (let x = 0; x < w; x += size) {
        const on = ((x / size) ^ (y / size)) & 1;
        ctx.fillStyle = on ? '#1a2230' : '#121820';
        ctx.fillRect(x, y, size, size);
      }
    }
  }

  function maskToImageData(mask, w, h, color, opacity) {
    const rgba = new Uint8ClampedArray(w * h * 4);
    const r = color[0], g = color[1], b = color[2];
    const op = clamp(opacity, 0, 1);
    for (let i = 0; i < w * h; i++) {
      const a = Math.round(mask[i] * op);
      const o = i * 4;
      rgba[o] = r; rgba[o + 1] = g; rgba[o + 2] = b; rgba[o + 3] = a;
    }
    return new ImageData(rgba, w, h);
  }

  function heatToImageData(mask, w, h) {
    const rgba = new Uint8ClampedArray(w * h * 4);
    for (let i = 0; i < w * h; i++) {
      const v = mask[i] / 255;
      const o = i * 4;
      rgba[o] = Math.round(20 + 40 * v);
      rgba[o + 1] = Math.round(80 + 140 * v);
      rgba[o + 2] = Math.round(120 + 135 * v);
      rgba[o + 3] = Math.round(40 + 215 * v);
    }
    return new ImageData(rgba, w, h);
  }

  function paintScene(canvas, params, mode) {
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;
    drawChecker(ctx, W, H, 14);

    const boxW = params.w, boxH = params.h;
    const built = buildShadow(params);
    const ox = Math.round(W / 2 - built.mw / 2 + params.offsetX);
    const oy = Math.round(H / 2 - built.mh / 2 + params.offsetY);

    if (mode === 'hard') {
      ctx.putImageData(maskToImageData(built.hard, built.mw, built.mh, [0, 0, 0], params.opacity), ox, oy);
    } else if (mode === 'heat') {
      ctx.putImageData(heatToImageData(built.soft, built.mw, built.mh), ox, oy);
    } else if (mode === 'wrong') {
      /* wrong: blur a solid colored rect as if color itself were blurred */
      ctx.save();
      ctx.globalAlpha = params.opacity;
      ctx.filter = `blur(${Math.max(0.5, params.blur / 2)}px)`;
      ctx.fillStyle = `rgb(${params.color.join(',')})`;
      roundRectPath(ctx, W / 2 - boxW / 2 + params.offsetX, H / 2 - boxH / 2 + params.offsetY, boxW, boxH, params.radius);
      ctx.fill();
      ctx.restore();
      ctx.filter = 'none';
    } else {
      ctx.putImageData(
        maskToImageData(built.soft, built.mw, built.mh, params.color, params.opacity),
        ox, oy
      );
    }

    if (mode !== 'heat' && mode !== 'hard') {
      ctx.fillStyle = params.body;
      roundRectPath(ctx, W / 2 - boxW / 2, H / 2 - boxH / 2, boxW, boxH, params.radius);
      ctx.fill();
      if (params.border) {
        ctx.strokeStyle = params.border;
        ctx.lineWidth = 2;
        roundRectPath(ctx, W / 2 - boxW / 2, H / 2 - boxH / 2, boxW, boxH, params.radius);
        ctx.stroke();
      }
    }
    return built;
  }

  function roundRectPath(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  /* ========== Hero video player ========== */
  function initHero() {
    const canvas = $('#hero-canvas');
    if (!canvas) return;
    const playBtn = $('#hero-play');
    const scrub = $('#hero-scrub');
    const label = $('#hero-stage-label');
    const stages = [
      { name: '硬圆角 Mask', mode: 'hard', blur: 0, spread: 0, offsetX: 0, offsetY: 0, opacity: 0.9, radius: 28 },
      { name: '外扩 Spread', mode: 'hard', blur: 0, spread: 14, offsetX: 0, offsetY: 0, opacity: 0.85, radius: 28 },
      { name: '1-Pass Box Blur', mode: 'final', blur: 18, spread: 8, offsetX: 10, offsetY: 14, opacity: 0.55, radius: 28, passes: 1 },
      { name: '3-Pass ≈ Gaussian', mode: 'final', blur: 22, spread: 8, offsetX: 12, offsetY: 18, opacity: 0.45, radius: 28, passes: 3 },
      { name: '彩色阴影合成', mode: 'final', blur: 26, spread: 6, offsetX: 16, offsetY: 22, opacity: 0.5, radius: 32, color: [20, 180, 220] },
      { name: '卡片落地态', mode: 'final', blur: 28, spread: 4, offsetX: 0, offsetY: 18, opacity: 0.42, radius: 26, color: [0, 0, 0] }
    ];

    let playing = true;
    let t0 = performance.now();
    const dur = 2200;

    function frameAt(ms) {
      const total = stages.length * dur;
      const m = ((ms % total) + total) % total;
      const idx = Math.floor(m / dur);
      const local = (m % dur) / dur;
      const a = stages[idx];
      const b = stages[(idx + 1) % stages.length];
      const ease = local < 0.15 ? 0 : local > 0.85 ? 1 : (local - 0.15) / 0.7;
      const e = ease * ease * (3 - 2 * ease);
      const params = {
        w: 180, h: 110,
        blur: Math.round(lerp(a.blur, b.blur, e)),
        spread: Math.round(lerp(a.spread, b.spread, e)),
        offsetX: Math.round(lerp(a.offsetX, b.offsetX, e)),
        offsetY: Math.round(lerp(a.offsetY, b.offsetY, e)),
        opacity: lerp(a.opacity, b.opacity, e),
        radius: Math.round(lerp(a.radius, b.radius, e)),
        passes: b.passes || a.passes || 3,
        color: [
          Math.round(lerp((a.color || [0, 0, 0])[0], (b.color || [0, 0, 0])[0], e)),
          Math.round(lerp((a.color || [0, 0, 0])[1], (b.color || [0, 0, 0])[1], e)),
          Math.round(lerp((a.color || [0, 0, 0])[2], (b.color || [0, 0, 0])[2], e))
        ],
        body: '#e8eef7',
        border: 'rgba(255,255,255,0.35)'
      };
      const mode = e < 0.5 ? (a.mode || 'final') : (b.mode || 'final');
      paintScene(canvas, params, mode === 'hard' ? 'hard' : 'final');
      if (label) label.textContent = e < 0.5 ? a.name : b.name;
      if (scrub) scrub.value = String(Math.round((m / total) * 1000));
    }

    function loop(now) {
      if (playing) frameAt(now - t0);
      requestAnimationFrame(loop);
    }
    requestAnimationFrame(loop);

    playBtn && playBtn.addEventListener('click', () => {
      playing = !playing;
      if (playing) t0 = performance.now() - (Number(scrub.value) / 1000) * stages.length * dur;
      playBtn.textContent = playing ? '暂停' : '播放';
      playBtn.setAttribute('aria-pressed', playing ? 'true' : 'false');
    });
    scrub && scrub.addEventListener('input', () => {
      playing = false;
      if (playBtn) playBtn.textContent = '播放';
      const ms = (Number(scrub.value) / 1000) * stages.length * dur;
      t0 = performance.now() - ms;
      frameAt(ms);
    });
  }

  /* ========== Pipeline scrubber ========== */
  function initPipeline() {
    const canvas = $('#pipe-canvas');
    const range = $('#pipe-step');
    const caption = $('#pipe-caption');
    if (!canvas || !range) return;
    const captions = [
      '① 生成硬圆角矩形 Alpha Mask（边缘 AA）',
      '② 水平居中 Box Blur（越界补 0，向四周扩散）',
      '③ 垂直居中 Box Blur（完成一次可分离模糊）',
      '④ 重复到 3-Pass，逼近高斯',
      '⑤ 阴影色 × Mask，再叠本体'
    ];
    const base = { w: 160, h: 96, blur: 24, spread: 8, offsetX: 14, offsetY: 18, opacity: 0.5, radius: 24, color: [0, 0, 0], body: '#f4f7fb', border: 'rgba(255,255,255,.3)' };

    function render(step) {
      const kn = shadowKernel(base.blur);
      const pad = shadowBlurPad(kn);
      const cw = base.w + base.spread * 2;
      const ch = base.h + base.spread * 2;
      const r = Math.min(base.radius + base.spread, cw >> 1, ch >> 1);
      const mw = cw + pad * 2, mh = ch + pad * 2;
      let mask = fillShadowMask(mw, mh, pad, cw, ch, [r, r, r, r]);
      if (step >= 1) mask = blurHorCentered(mask, mw, mh, kn);
      if (step >= 2) mask = blurVerCentered(mask, mw, mh, kn);
      if (step >= 3) {
        mask = blurHorCentered(mask, mw, mh, kn);
        mask = blurVerCentered(mask, mw, mh, kn);
        mask = blurHorCentered(mask, mw, mh, kn);
        mask = blurVerCentered(mask, mw, mh, kn);
      }
      const ctx = canvas.getContext('2d');
      drawChecker(ctx, canvas.width, canvas.height, 14);
      const ox = Math.round(canvas.width / 2 - mw / 2 + base.offsetX);
      const oy = Math.round(canvas.height / 2 - mh / 2 + base.offsetY);
      if (step < 4) ctx.putImageData(heatToImageData(mask, mw, mh), ox, oy);
      else {
        ctx.putImageData(maskToImageData(mask, mw, mh, base.color, base.opacity), ox, oy);
        ctx.fillStyle = base.body;
        roundRectPath(ctx, canvas.width / 2 - base.w / 2, canvas.height / 2 - base.h / 2, base.w, base.h, base.radius);
        ctx.fill();
      }
      if (caption) caption.textContent = captions[step];
    }
    range.addEventListener('input', () => render(Number(range.value)));
    render(0);

    let auto = true, acc = 0, last = performance.now();
    const toggle = $('#pipe-auto');
    toggle && toggle.addEventListener('click', () => {
      auto = !auto;
      toggle.textContent = auto ? '自动演示中' : '已暂停 · 点我继续';
    });
    function tick(now) {
      if (auto) {
        acc += now - last;
        if (acc > 1400) {
          acc = 0;
          range.value = String((Number(range.value) + 1) % 5);
          render(Number(range.value));
        }
      }
      last = now;
      requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  /* ========== Live playground ========== */
  function initPlayground() {
    const canvas = $('#play-canvas');
    if (!canvas) return;
    const fields = ['blur', 'spread', 'offsetX', 'offsetY', 'radius', 'opacity', 'passes'];
    const vals = {};
    const modeWrong = $('#mode-wrong');
    const modeHeat = $('#mode-heat');
    const cssOut = $('#css-out');
    const metaOut = $('#meta-out');

    function redraw() {
      const params = {
        w: 200, h: 120,
        blur: vals.blur || 0,
        spread: vals.spread || 0,
        offsetX: vals.offsetX || 0,
        offsetY: vals.offsetY || 0,
        radius: vals.radius || 0,
        opacity: vals.opacity == null ? 0.45 : vals.opacity,
        passes: vals.passes || 3,
        color: [0, 0, 0],
        body: '#f7fafc',
        border: 'rgba(255,255,255,0.4)'
      };
      let mode = 'final';
      if (modeWrong && modeWrong.checked) mode = 'wrong';
      if (modeHeat && modeHeat.checked) mode = 'heat';
      const built = paintScene(canvas, params, mode);
      if (cssOut) {
        cssOut.textContent =
          `box-shadow: ${params.offsetX}px ${params.offsetY}px ${params.blur}px ${params.spread}px rgba(0,0,0,${params.opacity.toFixed(2)});\n` +
          `border-radius: ${params.radius}px;`;
      }
      if (metaOut) {
        metaOut.textContent =
          `kn=${built.kn}  pad=${built.pad}  mask=${built.mw}×${built.mh}  core=${built.cw}×${built.ch}`;
      }
    }

    fields.forEach((id) => {
      const el = $('#' + id);
      const out = $('#' + id + '-val');
      if (!el) return;
      const sync = () => {
        vals[id] = id === 'opacity' ? Number(el.value) / 100 : Number(el.value);
        if (out) out.textContent = id === 'opacity' ? (vals[id].toFixed(2)) : String(vals[id]);
        redraw();
      };
      el.addEventListener('input', sync);
      sync();
    });
    modeWrong && modeWrong.addEventListener('change', redraw);
    modeHeat && modeHeat.addEventListener('change', redraw);
    redraw();
  }

  /* ========== Separable blur microscope ========== */
  function initBlurMicroscope() {
    const c0 = $('#blur-hard');
    const c1 = $('#blur-h');
    const c2 = $('#blur-v');
    const c3 = $('#blur-3');
    if (!c0) return;
    const knRange = $('#blur-kn');
    const knVal = $('#blur-kn-val');

    function drawMask(canvas, mask, w, h, title) {
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#0b1018';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      const scale = Math.min(canvas.width / w, canvas.height / h);
      const dw = Math.floor(w * scale), dh = Math.floor(h * scale);
      const tmp = document.createElement('canvas');
      tmp.width = w; tmp.height = h;
      tmp.getContext('2d').putImageData(heatToImageData(mask, w, h), 0, 0);
      const ox = (canvas.width - dw) >> 1, oy = (canvas.height - dh) >> 1;
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(tmp, ox, oy, dw, dh);
      ctx.fillStyle = 'rgba(232,238,247,0.8)';
      ctx.font = '12px JetBrains Mono, monospace';
      ctx.fillText(title, 10, 18);
    }

    function render() {
      const kn = Number(knRange.value);
      if (knVal) knVal.textContent = String(kn);
      const cw = 48, ch = 32, pad = shadowBlurPad(kn);
      const mw = cw + pad * 2, mh = ch + pad * 2;
      const hard = fillShadowMask(mw, mh, pad, cw, ch, [12, 12, 12, 12]);
      const h1 = blurHorCentered(hard, mw, mh, kn);
      const v1 = blurVerCentered(h1, mw, mh, kn);
      const g = blurPasses(hard, mw, mh, kn, 3);
      drawMask(c0, hard, mw, mh, 'Hard Mask');
      drawMask(c1, h1, mw, mh, 'H-pass');
      drawMask(c2, v1, mw, mh, 'H+V 1-pass');
      drawMask(c3, g, mw, mh, '3-pass');
    }
    knRange && knRange.addEventListener('input', render);
    render();
  }

  /* ========== Wrong vs Right split ========== */
  function initCompare() {
    const left = $('#cmp-wrong');
    const right = $('#cmp-right');
    if (!left || !right) return;
    const params = {
      w: 170, h: 100, blur: 28, spread: 6, offsetX: 10, offsetY: 16,
      opacity: 0.55, radius: 28, passes: 3, color: [12, 18, 28],
      body: '#edf2f7', border: 'rgba(255,255,255,.35)'
    };
    let t = 0;
    function tick() {
      t += 0.016;
      params.offsetX = Math.round(8 + Math.sin(t) * 10);
      params.offsetY = Math.round(14 + Math.cos(t * 0.9) * 8);
      params.blur = Math.round(22 + (Math.sin(t * 0.7) * 0.5 + 0.5) * 16);
      paintScene(left, params, 'wrong');
      paintScene(right, params, 'final');
      requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  /* ========== LRU cache theatre ========== */
  function initCache() {
    const stage = $('#cache-stage');
    const log = $('#cache-log');
    if (!stage) return;
    const keys = [
      { w: 120, h: 72, r: 16, kn: 13 },
      { w: 120, h: 72, r: 16, kn: 17 },
      { w: 160, h: 90, r: 24, kn: 13 },
      { w: 120, h: 72, r: 16, kn: 13 },
      { w: 200, h: 110, r: 28, kn: 21 },
      { w: 120, h: 72, r: 16, kn: 17 },
      { w: 120, h: 72, r: 16, kn: 13 }
    ];
    let i = 0;
    const pool = [];
    const MAX = 4;

    function keyStr(k) { return `${k.w}x${k.h}/r${k.r}/kn${k.kn}`; }

    function renderPool(msg, hit) {
      stage.innerHTML = '';
      pool.forEach((p, idx) => {
        const el = document.createElement('div');
        el.className = 'cache-item' + (idx === 0 ? ' hot' : '');
        el.innerHTML = `<strong>${keyStr(p)}</strong><span>age ${p.age}</span>`;
        stage.appendChild(el);
      });
      if (log) {
        const line = document.createElement('div');
        line.className = hit ? 'hit' : 'miss';
        line.textContent = msg;
        log.prepend(line);
        while (log.children.length > 8) log.lastChild.remove();
      }
    }

    function step() {
      const k = keys[i % keys.length];
      i++;
      const found = pool.findIndex((p) => keyStr(p) === keyStr(k));
      if (found >= 0) {
        const item = pool.splice(found, 1)[0];
        item.age = 0;
        pool.unshift(item);
        pool.forEach((p, idx) => { if (idx) p.age++; });
        renderPool(`HIT  ${keyStr(k)} → 直接 blend，跳过卷积`, true);
      } else {
        if (pool.length >= MAX) pool.pop();
        pool.forEach((p) => p.age++);
        pool.unshift({ ...k, age: 0 });
        renderPool(`MISS ${keyStr(k)} → fill mask + 3-pass blur + 入池`, false);
      }
    }

    step();
    setInterval(step, 1600);
    const btn = $('#cache-step');
    btn && btn.addEventListener('click', step);
  }

  /* ========== Preset gallery autoplay ========== */
  function initGallery() {
    const nodes = $$('[data-preset]');
    if (!nodes.length) return;
    const presets = {
      soft: { w: 140, h: 84, blur: 30, spread: 2, offsetX: 0, offsetY: 18, opacity: 0.35, radius: 22, color: [0, 0, 0], body: '#f8fafc' },
      neon: { w: 140, h: 84, blur: 26, spread: 0, offsetX: 0, offsetY: 0, opacity: 0.7, radius: 18, color: [0, 220, 255], body: '#102028', border: 'rgba(0,220,255,.45)' },
      float: { w: 140, h: 84, blur: 18, spread: 4, offsetX: 12, offsetY: 16, opacity: 0.4, radius: 14, color: [10, 16, 28], body: '#eef3f8' },
      pill: { w: 160, h: 56, blur: 22, spread: 0, offsetX: 0, offsetY: 10, opacity: 0.45, radius: 28, color: [0, 0, 0], body: '#ffffff' }
    };
    nodes.forEach((canvas) => {
      const key = canvas.getAttribute('data-preset');
      const p = Object.assign({}, presets[key]);
      let t = Math.random() * 10;
      function tick() {
        t += 0.02;
        const breathe = 0.5 + 0.5 * Math.sin(t);
        const local = Object.assign({}, p, {
          blur: Math.round(p.blur + breathe * 6),
          offsetY: Math.round(p.offsetY + Math.sin(t * 0.8) * 3)
        });
        paintScene(canvas, local, 'final');
        requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    });
  }

  /* ========== Sticky TOC active state ========== */
  function initTOC() {
    const links = $$('.toc a');
    if (!links.length) return;
    const map = links.map((a) => ({ a, el: document.querySelector(a.getAttribute('href')) })).filter((x) => x.el);
    const onScroll = () => {
      let cur = map[0];
      for (const item of map) {
        if (item.el.getBoundingClientRect().top < 120) cur = item;
      }
      links.forEach((a) => a.classList.toggle('active', a === cur.a));
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  document.addEventListener('DOMContentLoaded', () => {
    initHero();
    initPipeline();
    initPlayground();
    initBlurMicroscope();
    initCompare();
    initCache();
    initGallery();
    initTOC();
  });
})();
